package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;

/**
 * Created by raul.moriana on 23/3/2018.
 */

public class InputProcesador extends InputAdapter {

    private MainCharacter player;
    private Vector2 lastPosition;
    private boolean UpShoot;

    public InputProcesador(MainCharacter p){
        player = p;
        lastPosition = new Vector2();
    }

   @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        Vector2 newTouch = new Vector2(screenX,screenY);
        Vector2 delta = newTouch.cpy().sub(lastPosition);
        lastPosition = newTouch;
      if(newTouch.x < 90 && newTouch.y > Gdx.graphics.getHeight() - 90 && !player.isDeath){
           if(delta.y<0){
               player.goUp();
           }else{
               player.goDown();
           }
      }

        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        Vector2 newTouch = new Vector2(screenX,screenY);
        if(newTouch.x > Gdx.graphics.getWidth() - 90 &&  newTouch.y > Gdx.graphics.getHeight() - 90 && !player.isDeath){
            MyGdxGame.pS = new PlayerShoot(MyGdxGame.playerShootTexture);
            if(UpShoot == true){
                MyGdxGame.pS.setPosition(player.getX(),player.getY() + 25);
                UpShoot = false;
            }else{
                MyGdxGame.pS.setPosition(player.getX(),player.getY());
                UpShoot = true;
            }
            MyGdxGame.stage.addActor(MyGdxGame.pS);
            MyGdxGame.shootList.add(MyGdxGame.pS);
        }
        return super.touchUp(screenX, screenY, pointer, button);
    }
}
