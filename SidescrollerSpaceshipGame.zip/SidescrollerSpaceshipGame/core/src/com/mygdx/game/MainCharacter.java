package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;

/**
 * Created by raul.moriana on 23/3/2018.
 */

public class MainCharacter extends Actor{

    Texture texture;
    public int vida = 3;
    boolean isDeath;

    public MainCharacter(Texture texture) {
        this.texture = texture;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
            batch.draw(texture,getX(),getY(),75,50);
    }

    @Override
    public void act(float delta) {
        super.act(delta);
    }

    public void goUp(){
        if(getY() < Gdx.graphics.getHeight() - 70){
            setY(getY()+20);
        }
    }

    public void goDown(){
        if(getY() > 0) {
            setY(getY()-20);
        }
    }

    public void restaVida(){
        if (!isDeath) {
            vida --;
            if(vida == 0){
                isDeath = true;
            }
        }
    }
}
