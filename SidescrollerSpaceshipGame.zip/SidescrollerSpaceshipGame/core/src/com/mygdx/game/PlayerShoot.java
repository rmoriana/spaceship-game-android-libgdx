package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;

/**
 * Created by raul.moriana on 13/4/2018.
 */

public class PlayerShoot extends Actor {

    Texture texture;

    public PlayerShoot(Texture texture){
        this.texture = texture;
    }


    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(texture,getX(),getY(),15,20);
    }

    @Override
    public void act(float delta) {
        setX(getX()+10);
    }

    public void Destroy(){
        this.remove();
    }
}
