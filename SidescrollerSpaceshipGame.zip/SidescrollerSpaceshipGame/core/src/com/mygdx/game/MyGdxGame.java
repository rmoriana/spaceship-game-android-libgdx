package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Stage;
import java.util.*;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class MyGdxGame extends Game{

	SpriteBatch batch;
	Texture shipTexture, background, moveButton, shootButton, enemyTexture, hardEnemyTexture, hp1, hp2, hp3;
	MainCharacter ship;
	PlayerShoot playerShoot;
	Enemy enemy;
	HardEnemy hardEnemy;
	public int score = 0;

	BitmapFont font;
	BitmapFont finalText;

	public static ArrayList<Enemy> enemyList = new ArrayList<Enemy>();
	public static ArrayList<PlayerShoot> shootList = new ArrayList<PlayerShoot>();
	public static ArrayList<HardEnemy> hardEnemyList = new ArrayList<HardEnemy>();
	public static Iterator<Enemy> enemyIterator;
	public static Iterator<PlayerShoot> playerShootIterator;
	public static Iterator<HardEnemy> hardEnemyIterator;

	public static Texture playerShootTexture;
	private InputProcesador inputProc;
	public static Stage stage;
	public static PlayerShoot pS;
	Timer hardTimer = new Timer();
	int startTime = 4000;
	int interval = 12000;

	Timer timer = new Timer();
	int initialDelay = 0; // start after 1 seconds
	int period = 3000;

	@Override
	public void create () {

		stage = new Stage();
		font = new BitmapFont();
		finalText = new BitmapFont();
		hp1 = new Texture("heart.png");
		hp2 = new Texture("heart.png");
		hp3 = new Texture("heart.png");

		shipTexture = new Texture("player.png");
		ship = new MainCharacter(shipTexture);

		playerShootTexture = new Texture("playerShoot.png");
		playerShoot = new PlayerShoot(playerShootTexture);

		stage.addActor(ship);
		stage.addActor(playerShoot);

		ship.setPosition(5, Gdx.graphics.getHeight() / 2 + ship.getHeight() / 2);
		batch = new SpriteBatch();
		enemyTexture = new Texture("enemy.png");
		hardEnemyTexture = new Texture("hardEnemy.png");
		background = new Texture("bg.png");
		moveButton = new Texture("moveButton.png");
		shootButton = new Texture("shootButton.png");
		inputProc = new InputProcesador(ship);
		Gdx.input.setInputProcessor(inputProc);
		TimerTask task = new TimerTask() {
			public void run() {
				CreateEnemy();
			}
		};
		TimerTask task2 = new TimerTask() {
			public void run() {
				CreateHardEnemy();
			}
		};
		hardTimer.schedule(task2,startTime,interval);
		timer.schedule(task, initialDelay, period);

	/*	Music music = Gdx.audio.newMusic(Gdx.files.internal("data/audio.mp3"));
		music.play();
		music.setLooping(true);*/
	}

	@Override
	public void render () {
		super.render();
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		batch.draw(moveButton, 10, 10, 80, 80);
		if(ship.vida == 1){
			batch.draw(hp1, 10, Gdx.graphics.getHeight() - 40, 30, 30);
		}else if(ship.vida == 2){
			batch.draw(hp1, 10, Gdx.graphics.getHeight() - 40, 30, 30);
			batch.draw(hp2, 50, Gdx.graphics.getHeight() - 40, 30, 30);
		}else if(ship.vida == 3){
			batch.draw(hp1, 10, Gdx.graphics.getHeight() - 40, 30, 30);
			batch.draw(hp2, 50, Gdx.graphics.getHeight() - 40, 30, 30);
			batch.draw(hp3, 90, Gdx.graphics.getHeight() - 40, 30, 30);
		}
		if(ship.isDeath){
			finalText.draw(batch, "You've been defeated! \n Final score: "+score, Gdx.graphics.getWidth()/2 - 70, Gdx.graphics.getHeight()/2);
		}else{
			batch.draw(shootButton, Gdx.graphics.getWidth()-90, 10, 80, 80);
		}
		font.draw(batch, "Score: "+ score, Gdx.graphics.getWidth()-80, Gdx.graphics.getHeight() - 30);
		batch.end();
		stage.act();
		CheckShipCollisions();
		CheckCollisions();
		stage.draw();
	}
	
	@Override
	public void dispose () {
		super.dispose();
		stage.dispose();
		batch.dispose();
		//background.dispose();
	}

	public void CreateEnemy(){
		if(!ship.isDeath){
			enemy =  new Enemy(enemyTexture);
			Random rand = new Random();
			int  n = rand.nextInt(Gdx.graphics.getHeight() - 10) + 10;
			enemy.setPosition(Gdx.graphics.getWidth()+10, n);
			stage.addActor(enemy);
			enemyList.add(enemy);
		}
	}

	public void CreateHardEnemy(){
		if(!ship.isDeath) {
			hardEnemy = new HardEnemy(hardEnemyTexture);
			Random rand = new Random();
			int n = rand.nextInt(Gdx.graphics.getHeight() - 10) + 10;
			hardEnemy.setPosition(Gdx.graphics.getWidth() + 10, n);
			stage.addActor(hardEnemy);
			hardEnemyList.add(hardEnemy);
		}
	}

	void CheckShipCollisions(){

		enemyIterator = enemyList.iterator();
		hardEnemyIterator = hardEnemyList.iterator();

		while(enemyIterator.hasNext()){
			Enemy enemy = enemyIterator.next();
			if(ColisionX(enemy, ship) && ColisionY(enemy, ship)){
				ship.restaVida();
				enemy.Destroy();
			}
		}

		while(hardEnemyIterator.hasNext()){
			HardEnemy enemy = hardEnemyIterator.next();
			if(ColisionX(enemy, ship) && ColisionY(enemy, ship)){
				ship.restaVida();
				enemy.Destroy();
			}
		}
	}

	void CheckCollisions(){
		playerShootIterator = shootList.iterator();
		enemyIterator = enemyList.iterator();
		hardEnemyIterator = hardEnemyList.iterator();
		//Por cada bala comprueba las colisiones con los dos tipos de enemigos.
		while(playerShootIterator.hasNext()){
				PlayerShoot shoot = playerShootIterator.next();
				if(shoot.getX() > Gdx.graphics.getWidth()){
					shoot.Destroy();
					playerShootIterator.remove();
					continue;
				}
				while(enemyIterator.hasNext()){
					Enemy enemy = enemyIterator.next();
					if(enemy.getX() < -30){
						enemy.Destroy();
						continue;
					}
					if(ColisionX(enemy,shoot) && ColisionY(enemy,shoot)){
						score+=10;
						enemy.Destroy();
						playerShootIterator.remove();
						shoot.Destroy();
						break;
					}
				}
			while(hardEnemyIterator.hasNext()){
				HardEnemy hardEnemy = hardEnemyIterator.next();
				if(hardEnemy.getX() < -30){
					hardEnemy.Destroy();
					continue;
				}
				if(ColisionX(hardEnemy,shoot) && ColisionY(hardEnemy,shoot)){
					score+=50;
					hardEnemy.Destroy();
					playerShootIterator.remove();
					shoot.Destroy();
					break;
				}
			}
		}
	}

	private boolean ColisionX(Enemy enemy, PlayerShoot shoot){
		if(shoot.getX()+shoot.getWidth() >= enemy.getX() - enemy.getWidth()){
			return true;
		}
		return false;
	}

	private boolean ColisionX(Enemy enemy,   MainCharacter shoot){
		if(shoot.getX()+shoot.getWidth() >= enemy.getX() - enemy.getWidth()){
			return true;
		}
		return false;
	}

	private boolean ColisionX(HardEnemy enemy, MainCharacter shoot){
		if(shoot.getX()+shoot.getWidth() >= enemy.getX() - enemy.getWidth()){
			return true;
		}
		return false;
	}

	private boolean ColisionX(HardEnemy enemy, PlayerShoot shoot){
		if(shoot.getX()+shoot.getWidth() >= enemy.getX() - enemy.getWidth()){
			return true;
		}
		return false;
	}


	private boolean ColisionY(Enemy enemy, PlayerShoot shoot){
		if(shoot.getY()-shoot.getHeight() <= enemy.getY() + enemy.getHeight()+10 && shoot.getY() + shoot.getHeight() >= enemy.getY() - 10){
			return true;
		}
		return false;
	}

	private boolean ColisionY(HardEnemy enemy, PlayerShoot shoot){
		if(shoot.getY()-shoot.getHeight() <= enemy.getY() + enemy.getHeight()+20 && shoot.getY() + shoot.getHeight() >= enemy.getY() - 20){
			return true;
		}
		return false;
	}
	private boolean ColisionY(HardEnemy enemy, MainCharacter shoot){
		if(shoot.getY()-shoot.getHeight() <= enemy.getY() + enemy.getHeight()+20 && shoot.getY() + shoot.getHeight() >= enemy.getY() - 20){
			return true;
		}
		return false;
	}
	private boolean ColisionY(Enemy enemy,  MainCharacter shoot){
		if(shoot.getY()-shoot.getHeight() <= enemy.getY() + enemy.getHeight()+20 && shoot.getY() + shoot.getHeight() >= enemy.getY() - 20){
			return true;
		}
		return false;
	}
}
