package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;

/**
 * Created by raul.moriana on 27/4/2018.
 */

public class HardEnemy extends Actor {

    Texture texture;
    int health;
    Rectangle bounds;

    public HardEnemy(Texture texture){
        this.texture = texture;
        health = 1;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
            batch.draw(texture,getX(),getY(),120,80);
    }

    @Override
    public void act(float delta) {
        setX(getX()-1);
    }

    public void Destroy(){
        health--;
        if(health == 0){
            MyGdxGame.hardEnemyIterator.remove();
            this.remove();
        }
    }
}
