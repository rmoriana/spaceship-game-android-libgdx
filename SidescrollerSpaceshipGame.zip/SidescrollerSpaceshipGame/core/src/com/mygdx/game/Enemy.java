package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import java.util.Random;

/**
 * Created by raul.moriana on 20/4/2018.
 */

public class Enemy extends Actor {

    Texture texture;
    boolean isUp;
    int health;
    int speedX;
    int speedY;

    public Enemy(Texture texture){
        this.texture = texture;
        health = 1;
        Random rand = new Random();
        int n = rand.nextInt(2);
        if(n == 1){
            isUp = true;
        }
        speedX = rand.nextInt(3) + 1;
        speedY = rand.nextInt(3) + 1;

    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(texture,getX(),getY(),60,40);
    }

    @Override
    public void act(float delta) {
        setX(getX()-speedX);
        if(isUp) {
            setY(getY() + speedY);
            if(getY() >= Gdx.graphics.getHeight() - 20){
                isUp = false;
            }
        }else{
            setY(getY() - speedY);
            if(getY() <= 20){
                isUp = true;
            }
        }
    }

    public void Destroy(){
        health--;
        if(health == 0){
            MyGdxGame.enemyIterator.remove();
            this.remove();
        }
    }
}
